using UnityEngine;

public class PlaceReceiver : MonoBehaviour
{
    public static string CurrentPlace;

    public void SetCountry(string place)
    {
        CurrentPlace = place;
        Debug.Log("������ ���� place: " + place);
    }

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}
